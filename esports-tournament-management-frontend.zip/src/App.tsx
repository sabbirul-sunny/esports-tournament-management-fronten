import {
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import {
  Trophy,
  Users,
  Swords,
  Calendar,
  Clock,
  ShieldAlert,
  UserCog,
  Gamepad2,
  Crosshair,
  Smartphone,
  Flame,
  CircleDot,
  Bomb,
  Castle,
  Activity,
  Play,
  X,
  ChevronLeft,
  LogOut,
  Zap,
  Target,
  Medal,
  MonitorPlay,
  Plus,
  Trash2,
  Save,
  AlertTriangle,
  Crown,
} from "lucide-react";
import { cn } from "@/utils/cn";

// ---------------------------------------------------------------------------
// Types
// ---------------------------------------------------------------------------

type Role = "team" | "admin";

type User =
  | { role: "team"; teamId: string }
  | { role: "admin"; name: string };

type AccentKey =
  | "cyan"
  | "fuchsia"
  | "emerald"
  | "amber"
  | "rose"
  | "violet"
  | "orange"
  | "lime";

type Standing = {
  teamId: string;
  matches: number;
  wins: number;
  killsPoints: number;
  totalScore: number;
};

type FixtureStatus = "UPCOMING" | "LIVE" | "FINISHED";

type Fixture = {
  id: string;
  teamAId: string;
  teamBId: string;
  status: FixtureStatus;
  scheduledAt: number;
};

type Game = {
  id: string;
  name: string;
  short: string;
  accent: AccentKey;
  startAt: number;
  prizeFirst: number;
  prizeSecond: number;
  maxTeams: number;
  registeredTeamIds: string[];
  standings: Standing[];
  fixtures: Fixture[];
};

type Team = {
  id: string;
  name: string;
  members: string[];
  manager: string;
  password: string;
};

// ---------------------------------------------------------------------------
// Theme
// ---------------------------------------------------------------------------

const ACCENT: Record<
  AccentKey,
  {
    border: string;
    text: string;
    bg: string;
    glow: string;
    gradient: string;
    soft: string;
    ring: string;
  }
> = {
  cyan: {
    border: "border-cyan-500/40",
    text: "text-cyan-400",
    bg: "bg-cyan-500",
    glow: "glow-cyan",
    gradient: "from-cyan-500 to-blue-600",
    soft: "bg-cyan-500/10",
    ring: "ring-cyan-500/40",
  },
  fuchsia: {
    border: "border-fuchsia-500/40",
    text: "text-fuchsia-400",
    bg: "bg-fuchsia-500",
    glow: "glow-fuchsia",
    gradient: "from-fuchsia-500 to-purple-600",
    soft: "bg-fuchsia-500/10",
    ring: "ring-fuchsia-500/40",
  },
  emerald: {
    border: "border-emerald-500/40",
    text: "text-emerald-400",
    bg: "bg-emerald-500",
    glow: "glow-emerald",
    gradient: "from-emerald-500 to-teal-600",
    soft: "bg-emerald-500/10",
    ring: "ring-emerald-500/40",
  },
  amber: {
    border: "border-amber-500/40",
    text: "text-amber-400",
    bg: "bg-amber-500",
    glow: "glow-amber",
    gradient: "from-amber-500 to-orange-600",
    soft: "bg-amber-500/10",
    ring: "ring-amber-500/40",
  },
  rose: {
    border: "border-rose-500/40",
    text: "text-rose-400",
    bg: "bg-rose-500",
    glow: "glow-rose",
    gradient: "from-rose-500 to-pink-600",
    soft: "bg-rose-500/10",
    ring: "ring-rose-500/40",
  },
  violet: {
    border: "border-violet-500/40",
    text: "text-violet-400",
    bg: "bg-violet-500",
    glow: "glow-violet",
    gradient: "from-violet-500 to-indigo-600",
    soft: "bg-violet-500/10",
    ring: "ring-violet-500/40",
  },
  orange: {
    border: "border-orange-500/40",
    text: "text-orange-400",
    bg: "bg-orange-500",
    glow: "glow-orange",
    gradient: "from-orange-500 to-amber-600",
    soft: "bg-orange-500/10",
    ring: "ring-orange-500/40",
  },
  lime: {
    border: "border-lime-500/40",
    text: "text-lime-400",
    bg: "bg-lime-500",
    glow: "glow-lime",
    gradient: "from-lime-500 to-emerald-600",
    soft: "bg-lime-500/10",
    ring: "ring-lime-500/40",
  },
};

const GAME_ICONS: Record<string, ReactNode> = {
  pubgm: <Crosshair className="h-6 w-6" />,
  valorant: <Target className="h-6 w-6" />,
  mlbb: <Smartphone className="h-6 w-6" />,
  freefire: <Flame className="h-6 w-6" />,
  fifa: <CircleDot className="h-6 w-6" />,
  codm: <Bomb className="h-6 w-6" />,
  coc: <Castle className="h-6 w-6" />,
  efootball: <Activity className="h-6 w-6" />,
};

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

const generateId = () => Math.random().toString(36).slice(2, 10);

const formatCurrency = (n: number) => `$${n.toLocaleString()}`;

const formatDateTime = (ts: number) =>
  new Date(ts).toLocaleString("en-US", {
    month: "short",
    day: "numeric",
    hour: "2-digit",
    minute: "2-digit",
  });

const formatCountdown = (ms: number) => {
  const clamped = Math.max(0, ms);
  const days = Math.floor(clamped / 86_400_000);
  const hours = Math.floor((clamped % 86_400_000) / 3_600_000);
  const minutes = Math.floor((clamped % 3_600_000) / 60_000);
  const seconds = Math.floor((clamped % 60_000) / 1_000);
  return `${days}d ${hours.toString().padStart(2, "0")}h ${minutes
    .toString()
    .padStart(2, "0")}m ${seconds.toString().padStart(2, "0")}s`;
};

function createMockTeams(): Team[] {
  const roster = [
    ["Ace", "Blitz", "Cypher", "Dash", "Echo"],
    ["Frost", "Grim", "Havoc", "Ion", "Jolt"],
    ["Karma", "Lunar", "Maverick", "Nexo", "Onyx"],
    ["Phantom", "Quake", "Raze", "Storm", "Titan"],
    ["Umbra", "Vex", "Wraith", "Xeno", "Ymir"],
    ["Zero", "Alpha", "Bravo", "Charlie", "Delta"],
    ["Echo2", "Foxtrot", "Golf", "Hotel", "India"],
    ["Juliet", "Kilo", "Lima", "Mike", "November"],
    ["Oscar", "Papa", "Quebec", "Romeo", "Sierra"],
    ["Tango", "Uniform", "Victor", "Whiskey", "Xray"],
    ["Yankee", "Zulu", "Ajax", "Bolt", "Cobra"],
    ["Dagger", "Eagle", "Falcon", "Ghost", "Hunter"],
    ["Inferno", "Jungle", "Knight", "Legend", "Mythic"],
    ["Nova2", "Omega", "Prime", "Quest", "Rogue"],
    ["Spartan", "Thunder", "Ultra", "Venom", "Warrior"],
    ["Xcalibur", "Yeti", "Zenith", "Abyss", "Bastion"],
  ];
  const names = [
    "Nova Elite",
    "Vortex Gaming",
    "Phantom Strikers",
    "Crimson Aces",
    "Neon Spartans",
    "Cyber Wolves",
    "Apex Predators",
    "Shadow Squad",
    "Titan Force",
    "Blaze United",
    "Storm Raiders",
    "Dusk Legion",
    "Iron Giants",
    "Rogue Empire",
    "Echo Dragons",
    "Solar Phoenix",
  ];
  const managers = [
    "Marcus", "Lena", "Diego", "Yuki", "Sam", "Aisha", "Omar", "Elena",
    "Leo", "Maya", "Kai", "Nora", "Ivan", "Sofia", "Noah", "Zara",
  ];
  return names.map((name, i) => ({
    id: `team-${i + 1}`,
    name,
    members: roster[i],
    manager: managers[i],
    password: "1234",
  }));
}

function createInitialGames(teams: Team[]): Game[] {
  const now = Date.now();
  const catalog: Omit<Game, "registeredTeamIds" | "standings" | "fixtures">[] = [
    {
      id: "pubgm",
      name: "PUBG Mobile",
      short: "PUBGM",
      accent: "cyan",
      startAt: now + 2 * 86_400_000,
      prizeFirst: 5_000,
      prizeSecond: 2_500,
      maxTeams: 16,
    },
    {
      id: "valorant",
      name: "Valorant",
      short: "VAL",
      accent: "fuchsia",
      startAt: now + 3 * 86_400_000,
      prizeFirst: 6_000,
      prizeSecond: 3_000,
      maxTeams: 16,
    },
    {
      id: "mlbb",
      name: "Mobile Legends",
      short: "MLBB",
      accent: "emerald",
      startAt: now + 1 * 86_400_000,
      prizeFirst: 4_000,
      prizeSecond: 2_000,
      maxTeams: 16,
    },
    {
      id: "freefire",
      name: "Free Fire",
      short: "FF",
      accent: "amber",
      startAt: now + 4 * 86_400_000,
      prizeFirst: 3_500,
      prizeSecond: 1_750,
      maxTeams: 16,
    },
    {
      id: "fifa",
      name: "FIFA",
      short: "FIFA",
      accent: "rose",
      startAt: now + 2.5 * 86_400_000,
      prizeFirst: 2_500,
      prizeSecond: 1_250,
      maxTeams: 16,
    },
    {
      id: "codm",
      name: "Call of Duty Mobile",
      short: "CODM",
      accent: "violet",
      startAt: now + 5 * 86_400_000,
      prizeFirst: 4_500,
      prizeSecond: 2_250,
      maxTeams: 16,
    },
    {
      id: "coc",
      name: "Clash of Clans",
      short: "CoC",
      accent: "orange",
      startAt: now + 6 * 86_400_000,
      prizeFirst: 3_000,
      prizeSecond: 1_500,
      maxTeams: 16,
    },
    {
      id: "efootball",
      name: "eFootball",
      short: "eFB",
      accent: "lime",
      startAt: now + 3.5 * 86_400_000,
      prizeFirst: 3_200,
      prizeSecond: 1_600,
      maxTeams: 16,
    },
  ];

  return catalog.map((g, idx) => {
    // First game is full, others at 12/16 for the demo counter
    const count = idx === 0 ? 16 : 12;
    const registeredTeamIds = teams.slice(0, count).map((t) => t.id);

    const standings: Standing[] = registeredTeamIds.map((teamId) => {
      const matches = Math.floor(Math.random() * 8) + 1;
      const wins = Math.floor(Math.random() * (matches + 1));
      const killsPoints = Math.floor(Math.random() * 120) + 10;
      const totalScore = wins * 10 + killsPoints;
      return { teamId, matches, wins, killsPoints, totalScore };
    });

    const fixtures: Fixture[] = [];
    const fixtureCount = Math.floor(registeredTeamIds.length / 2);
    for (let i = 0; i < fixtureCount; i++) {
      const teamAId = registeredTeamIds[i * 2];
      const teamBId = registeredTeamIds[i * 2 + 1];
      const scheduledAt = g.startAt + (i - fixtureCount / 2) * 3_600_000;
      let status: FixtureStatus = "UPCOMING";
      if (scheduledAt < now - 3_600_000) status = "FINISHED";
      else if (scheduledAt <= now + 1_800_000 && scheduledAt >= now - 1_800_000)
        status = "LIVE";
      fixtures.push({
        id: generateId(),
        teamAId,
        teamBId,
        status,
        scheduledAt,
      });
    }

    return { ...g, registeredTeamIds, standings, fixtures };
  });
}

// ---------------------------------------------------------------------------
// Components
// ---------------------------------------------------------------------------

function Badge({
  children,
  variant = "neutral",
  className,
}: {
  children: React.ReactNode;
  variant?: "neutral" | "success" | "warning" | "danger" | "info";
  className?: string;
}) {
  const map = {
    neutral: "bg-slate-800 text-slate-300 border-slate-700",
    success: "bg-emerald-500/10 text-emerald-400 border-emerald-500/30",
    warning: "bg-amber-500/10 text-amber-400 border-amber-500/30",
    danger: "bg-rose-500/10 text-rose-400 border-rose-500/30",
    info: "bg-cyan-500/10 text-cyan-400 border-cyan-500/30",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-semibold uppercase tracking-wider",
        map[variant],
        className
      )}
    >
      {children}
    </span>
  );
}

function StatusDot({ status }: { status: FixtureStatus }) {
  if (status === "LIVE") {
    return (
      <span className="relative flex h-2.5 w-2.5">
        <span className="live-dot absolute inline-flex h-full w-full rounded-full bg-rose-500 opacity-75"></span>
        <span className="relative inline-flex h-2.5 w-2.5 rounded-full bg-rose-500"></span>
      </span>
    );
  }
  if (status === "FINISHED") {
    return <span className="h-2 w-2 rounded-full bg-slate-500" />;
  }
  return <span className="h-2 w-2 rounded-full bg-cyan-400" />;
}

function AuthModal({
  role,
  teams,
  onLogin,
  onSwitchRole,
}: {
  role: Role;
  teams: Team[];
  onLogin: (user: User, newTeam?: Team) => void;
  onSwitchRole: () => void;
}) {
  const [teamName, setTeamName] = useState("");
  const [members, setMembers] = useState("");
  const [manager, setManager] = useState("");
  const [password, setPassword] = useState("");
  const [adminName, setAdminName] = useState("");
  const [adminPassword, setAdminPassword] = useState("");
  const [error, setError] = useState("");

  useEffect(() => {
    setError("");
  }, [role]);

  const handleTeamAuth = (isRegister: boolean) => {
    setError("");
    const name = teamName.trim();
    const mgr = manager.trim();
    const pwd = password.trim();
    if (!name || !mgr || !pwd) {
      setError("Please fill in all required fields.");
      return;
    }
    const memberList = members
      .split(",")
      .map((s) => s.trim())
      .filter(Boolean);
    if (memberList.length < 2) {
      setError("Enter at least two team member names separated by commas.");
      return;
    }

    if (isRegister) {
      const exists = teams.find(
        (t) => t.name.toLowerCase() === name.toLowerCase()
      );
      if (exists) {
        setError("A team with that name already exists. Try logging in.");
        return;
      }
      const newTeam: Team = {
        id: generateId(),
        name,
        members: memberList,
        manager: mgr,
        password: pwd,
      };
      onLogin({ role: "team", teamId: newTeam.id }, newTeam);
    } else {
      const found = teams.find(
        (t) => t.name.toLowerCase() === name.toLowerCase()
      );
      if (!found) {
        setError("Team not found. Check the name or register a new team.");
        return;
      }
      if (found.password !== pwd) {
        setError("Incorrect password.");
        return;
      }
      onLogin({ role: "team", teamId: found.id });
    }
  };

  const handleAdminAuth = () => {
    setError("");
    const name = adminName.trim();
    const pwd = adminPassword.trim();
    if (!name || !pwd) {
      setError("Enter admin credentials.");
      return;
    }
    if (pwd !== "admin") {
      setError("Invalid admin password. Hint: admin");
      return;
    }
    onLogin({ role: "admin", name });
  };

  return (
    <div className="flex min-h-[calc(100vh-80px)] items-center justify-center p-6">
      <div className="w-full max-w-md overflow-hidden rounded-2xl border border-slate-700 bg-slate-900/80 shadow-2xl backdrop-blur-md">
        <div className="relative overflow-hidden bg-gradient-to-r from-slate-800 to-slate-900 p-6 text-center">
          <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-cyan-500/10 blur-2xl" />
          <div className="absolute -bottom-6 -left-6 h-24 w-24 rounded-full bg-fuchsia-500/10 blur-2xl" />
          <div className="relative">
            <div className="mx-auto mb-3 flex h-14 w-14 items-center justify-center rounded-xl border border-cyan-500/30 bg-cyan-500/10 text-cyan-400 glow-cyan">
              {role === "team" ? (
                <Users className="h-7 w-7" />
              ) : (
                <UserCog className="h-7 w-7" />
              )}
            </div>
            <h2 className="font-display text-2xl font-bold uppercase tracking-wider text-white">
              {role === "team" ? "Team Access" : "Admin Access"}
            </h2>
            <p className="mt-1 text-sm text-slate-400">
              {role === "team"
                ? "Register or login your squad"
                : "Tournament control login"}
            </p>
          </div>
        </div>

        <div className="p-6">
          {error && (
            <div className="mb-4 flex items-start gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 p-3 text-sm text-rose-300">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              {error}
            </div>
          )}

          {role === "team" ? (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handleTeamAuth(false);
              }}
            >
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Team Name
                </label>
                <input
                  type="text"
                  value={teamName}
                  onChange={(e) => setTeamName(e.target.value)}
                  placeholder="e.g. Nova Elite"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white outline-none ring-0 transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Team Member Names
                </label>
                <textarea
                  value={members}
                  onChange={(e) => setMembers(e.target.value)}
                  placeholder="Ace, Blitz, Cypher, Dash, Echo"
                  rows={3}
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                />
                <p className="mt-1 text-xs text-slate-500">
                  Separate names with commas.
                </p>
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Team Manager Name
                </label>
                <input
                  type="text"
                  value={manager}
                  onChange={(e) => setManager(e.target.value)}
                  placeholder="Manager name"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Password
                </label>
                <input
                  type="password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-500/20"
                />
              </div>
              <div className="grid grid-cols-2 gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => handleTeamAuth(true)}
                  className="rounded-lg border border-cyan-500/30 bg-cyan-500/10 px-4 py-2.5 text-sm font-bold uppercase tracking-wider text-cyan-400 transition hover:bg-cyan-500/20"
                >
                  Register
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-gradient-to-r from-cyan-500 to-blue-600 px-4 py-2.5 text-sm font-bold uppercase tracking-wider text-white shadow-lg shadow-cyan-500/25 transition hover:shadow-cyan-500/40"
                >
                  Login
                </button>
              </div>
            </form>
          ) : (
            <form
              className="space-y-4"
              onSubmit={(e) => {
                e.preventDefault();
                handleAdminAuth();
              }}
            >
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Admin Name
                </label>
                <input
                  type="text"
                  value={adminName}
                  onChange={(e) => setAdminName(e.target.value)}
                  placeholder="Tournament Admin"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white outline-none transition focus:border-fuchsia-500 focus:ring-2 focus:ring-fuchsia-500/20"
                />
              </div>
              <div>
                <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Password
                </label>
                <input
                  type="password"
                  value={adminPassword}
                  onChange={(e) => setAdminPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full rounded-lg border border-slate-700 bg-slate-950 px-4 py-2.5 text-sm text-white outline-none transition focus:border-fuchsia-500 focus:ring-2 focus:ring-fuchsia-500/20"
                />
                <p className="mt-1 text-xs text-slate-500">Demo password: admin</p>
              </div>
              <button
                type="submit"
                className="w-full rounded-lg bg-gradient-to-r from-fuchsia-500 to-purple-600 px-4 py-2.5 text-sm font-bold uppercase tracking-wider text-white shadow-lg shadow-fuchsia-500/25 transition hover:shadow-fuchsia-500/40"
              >
                Login as Admin
              </button>
            </form>
          )}

          <div className="mt-6 border-t border-slate-800 pt-4">
            <p className="mb-2 text-center text-xs font-semibold uppercase tracking-wider text-slate-500">
              Quick Demo
            </p>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() =>
                  onLogin({ role: "team", teamId: teams[0]?.id || "" })
                }
                className="rounded-lg border border-slate-700 bg-slate-800/50 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-slate-800"
              >
                Team: {teams[0]?.name}
              </button>
              <button
                onClick={() => onLogin({ role: "admin", name: "Demo Admin" })}
                className="rounded-lg border border-slate-700 bg-slate-800/50 px-3 py-2 text-xs font-semibold text-slate-300 transition hover:bg-slate-800"
              >
                Admin
              </button>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={onSwitchRole}
        className="fixed bottom-6 right-6 z-40 flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900/90 px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-300 shadow-lg backdrop-blur transition hover:border-cyan-500/50 hover:text-cyan-400"
      >
        <Zap className="h-3.5 w-3.5 text-cyan-400" />
        Switch Role: {role === "team" ? "Admin" : "Team"}
      </button>
    </div>
  );
}

function GameCard({
  game,
  user,
  isRegistered,
  onSelect,
  onRegister,
}: {
  game: Game;
  user: User | null;
  isRegistered: boolean;
  onSelect: () => void;
  onRegister: (e: React.MouseEvent) => void;
}) {
  const theme = ACCENT[game.accent];
  const registered = game.registeredTeamIds.length;
  const full = registered >= game.maxTeams;
  const pct = (registered / game.maxTeams) * 100;

  return (
    <div
      onClick={onSelect}
      className={cn(
        "group relative cursor-pointer overflow-hidden rounded-2xl border bg-slate-900/70 p-5 transition duration-300 hover:-translate-y-1 hover:bg-slate-800/80",
        theme.border,
        "hover:shadow-2xl",
        theme.glow
      )}
    >
      <div
        className={cn(
          "absolute inset-x-0 top-0 h-1 bg-gradient-to-r",
          theme.gradient
        )}
      />
      <div className="mb-4 flex items-start justify-between">
        <div
          className={cn(
            "flex h-12 w-12 items-center justify-center rounded-xl border bg-slate-950",
            theme.border,
            theme.text
          )}
        >
          {GAME_ICONS[game.id] || <Gamepad2 className="h-6 w-6" />}
        </div>
        <Badge
          variant={full ? "success" : "info"}
          className={cn(full ? "" : theme.text)}
        >
          {registered}/{game.maxTeams} Registered
        </Badge>
      </div>

      <h3 className="font-display text-lg font-bold uppercase tracking-wide text-white">
        {game.name}
      </h3>
      <p className="mt-1 text-xs font-medium text-slate-400">{game.short}</p>

      <div className="mt-4 space-y-2 text-sm">
        <div className="flex items-center gap-2 text-slate-300">
          <Calendar className="h-4 w-4 text-slate-500" />
          <span>{formatDateTime(game.startAt)}</span>
        </div>
        <div className="flex items-center gap-2 text-slate-300">
          <Trophy className="h-4 w-4 text-amber-400" />
          <span>
            1st {formatCurrency(game.prizeFirst)} · 2nd{" "}
            {formatCurrency(game.prizeSecond)}
          </span>
        </div>
      </div>

      <div className="mt-4">
        <div className="mb-1 flex justify-between text-xs font-semibold uppercase tracking-wider text-slate-400">
          <span>Slots</span>
          <span className={theme.text}>{Math.round(pct)}%</span>
        </div>
        <div className="h-2 w-full overflow-hidden rounded-full bg-slate-800">
          <div
            className={cn("h-full rounded-full bg-gradient-to-r", theme.gradient)}
            style={{ width: `${pct}%` }}
          />
        </div>
      </div>

      <div className="mt-5 flex items-center gap-2">
        {user?.role === "team" ? (
          <button
            onClick={onRegister}
            disabled={isRegistered || full}
            className={cn(
              "flex-1 rounded-lg py-2 text-xs font-bold uppercase tracking-wider transition",
              isRegistered || full
                ? "cursor-not-allowed border border-slate-700 bg-slate-800 text-slate-500"
                : cn(
                    "bg-gradient-to-r text-white shadow-lg",
                    theme.gradient,
                    "hover:brightness-110"
                  )
            )}
          >
            {isRegistered
              ? "Registered"
              : full
              ? "Tournament Full"
              : "Register Team"}
          </button>
        ) : (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onSelect();
            }}
            className={cn(
              "flex-1 rounded-lg border py-2 text-xs font-bold uppercase tracking-wider transition",
              theme.border,
              theme.text,
              "hover:bg-slate-800"
            )}
          >
            Manage
          </button>
        )}
        <button
          onClick={(e) => {
            e.stopPropagation();
            onSelect();
          }}
          className="rounded-lg border border-slate-700 bg-slate-800/50 p-2 text-slate-300 transition hover:bg-slate-800"
        >
          <ChevronLeft className="h-4 w-4 rotate-180" />
        </button>
      </div>
    </div>
  );
}

function LiveStreamModal({
  game,
  fixture,
  teams,
  onClose,
}: {
  game: Game;
  fixture: Fixture;
  teams: Team[];
  onClose: () => void;
}) {
  const teamA = teams.find((t) => t.id === fixture.teamAId);
  const teamB = teams.find((t) => t.id === fixture.teamBId);
  const theme = ACCENT[game.accent];

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 p-4 backdrop-blur-sm">
      <div
        className={cn(
          "w-full max-w-4xl overflow-hidden rounded-2xl border bg-slate-900 shadow-2xl",
          theme.border
        )}
      >
        <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
          <div className="flex items-center gap-3">
            <MonitorPlay className={cn("h-5 w-5", theme.text)} />
            <h3 className="font-display text-lg font-bold uppercase tracking-wide text-white">
              Match Stream
            </h3>
            <Badge
              variant={
                fixture.status === "LIVE"
                  ? "danger"
                  : fixture.status === "FINISHED"
                  ? "neutral"
                  : "info"
              }
            >
              <StatusDot status={fixture.status} />
              {fixture.status}
            </Badge>
          </div>
          <button
            onClick={onClose}
            className="rounded-lg border border-slate-700 p-1.5 text-slate-400 transition hover:bg-slate-800 hover:text-white"
          >
            <X className="h-5 w-5" />
          </button>
        </div>

        <div className="p-5">
          <div className="mb-4 flex flex-col items-center justify-between gap-4 sm:flex-row">
            <div className="text-center sm:text-left">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Matchup
              </p>
              <p className="font-display text-2xl font-bold text-white">
                {teamA?.name || "TBD"}{" "}
                <span className={theme.text}>vs</span>{" "}
                {teamB?.name || "TBD"}
              </p>
            </div>
            <div className="text-center sm:text-right">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Scheduled
              </p>
              <p className="text-sm font-medium text-slate-300">
                {formatDateTime(fixture.scheduledAt)}
              </p>
            </div>
          </div>

          <div className="relative aspect-video w-full overflow-hidden rounded-xl border border-slate-800 bg-black">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,_var(--tw-gradient-stops))] from-slate-800 via-black to-black opacity-80" />
            <div className="relative flex h-full flex-col items-center justify-center gap-4">
              <div
                className={cn(
                  "flex h-16 w-16 items-center justify-center rounded-full border bg-slate-900/80",
                  theme.border,
                  theme.text
                )}
              >
                <Play className="h-8 w-8 fill-current" />
              </div>
              <p className="font-display text-lg font-bold uppercase tracking-widest text-white">
                Stream Offline
              </p>
              <p className="max-w-md text-center text-sm text-slate-400">
                This is a mock Twitch/YouTube embed placeholder. In production,
                the live broadcast would load here.
              </p>
              {fixture.status === "LIVE" && (
                <div className="absolute right-4 top-4 flex items-center gap-2 rounded-full border border-rose-500/30 bg-rose-500/10 px-3 py-1 text-xs font-bold uppercase tracking-wider text-rose-400">
                  <span className="live-dot inline-block h-2 w-2 rounded-full bg-rose-500" />
                  Live Now
                </div>
              )}
            </div>
          </div>

          <div className="mt-5 grid gap-3 sm:grid-cols-2">
            <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {teamA?.name || "Team A"}
              </p>
              <p className="mt-1 text-sm text-slate-300">
                {teamA?.members.join(", ") || "—"}
              </p>
            </div>
            <div className="rounded-xl border border-slate-800 bg-slate-950/50 p-4">
              <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                {teamB?.name || "Team B"}
              </p>
              <p className="mt-1 text-sm text-slate-300">
                {teamB?.members.join(", ") || "—"}
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main App
// ---------------------------------------------------------------------------

export default function App() {
  const [teams, setTeams] = useState<Team[]>(createMockTeams);
  const [games, setGames] = useState<Game[]>(() => createInitialGames(createMockTeams()));
  const [role, setRole] = useState<Role>("team");
  const [user, setUser] = useState<User | null>(null);
  const [selectedGameId, setSelectedGameId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<"roster" | "standings" | "fixtures">("standings");
  const [now, setNow] = useState(Date.now());
  const [fixtureModal, setFixtureModal] = useState<Fixture | null>(null);
  const [savedFlash, setSavedFlash] = useState(false);

  const selectedGame = useMemo(
    () => games.find((g) => g.id === selectedGameId) || null,
    [games, selectedGameId]
  );

  useEffect(() => {
    const id = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(id);
  }, []);

  useEffect(() => {
    if (user) setRole(user.role);
  }, [user]);

  const handleAuth = (newUser: User, newTeam?: Team) => {
    if (newUser.role === "team" && newTeam) {
      setTeams((prev) =>
        prev.some((t) => t.id === newTeam.id) ? prev : [...prev, newTeam]
      );
    }
    setUser(newUser);
  };

  const switchRole = () => {
    const next: Role = role === "team" ? "admin" : "team";
    setRole(next);
    if (user && user.role !== next) setUser(null);
  };

  const registerTeamForGame = (gameId: string) => {
    if (!user || user.role !== "team") return;
    setGames((prev) =>
      prev.map((g) => {
        if (g.id !== gameId) return g;
        if (g.registeredTeamIds.includes(user.teamId)) return g;
        if (g.registeredTeamIds.length >= g.maxTeams) return g;
        return {
          ...g,
          registeredTeamIds: [...g.registeredTeamIds, user.teamId],
          standings: [
            ...g.standings,
            { teamId: user.teamId, matches: 0, wins: 0, killsPoints: 0, totalScore: 0 },
          ],
        };
      })
    );
  };

  const banTeam = (gameId: string, teamId: string) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id !== gameId) return g;
        return {
          ...g,
          registeredTeamIds: g.registeredTeamIds.filter((id) => id !== teamId),
          standings: g.standings.filter((s) => s.teamId !== teamId),
          fixtures: g.fixtures.filter(
            (f) => f.teamAId !== teamId && f.teamBId !== teamId
          ),
        };
      })
    );
  };

  const updateStanding = (
    gameId: string,
    teamId: string,
    field: keyof Standing,
    value: number
  ) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id !== gameId) return g;
        return {
          ...g,
          standings: g.standings.map((s) =>
            s.teamId === teamId ? { ...s, [field]: value } : s
          ),
        };
      })
    );
  };

  const updateFixture = (
    gameId: string,
    fixtureId: string,
    patch: Partial<Fixture>
  ) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id !== gameId) return g;
        return {
          ...g,
          fixtures: g.fixtures.map((f) =>
            f.id === fixtureId ? { ...f, ...patch } : f
          ),
        };
      })
    );
  };

  const addFixture = (gameId: string) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id !== gameId) return g;
        const ids = g.registeredTeamIds;
        const teamAId = ids[0] || "";
        const teamBId = ids[1] || "";
        const fixture: Fixture = {
          id: generateId(),
          teamAId,
          teamBId,
          status: "UPCOMING",
          scheduledAt: Date.now() + 3_600_000,
        };
        return { ...g, fixtures: [...g.fixtures, fixture] };
      })
    );
  };

  const deleteFixture = (gameId: string, fixtureId: string) => {
    setGames((prev) =>
      prev.map((g) => {
        if (g.id !== gameId) return g;
        return {
          ...g,
          fixtures: g.fixtures.filter((f) => f.id !== fixtureId),
        };
      })
    );
  };

  const sortedStandings = useMemo(() => {
    if (!selectedGame) return [];
    return [...selectedGame.standings].sort((a, b) => b.totalScore - a.totalScore);
  }, [selectedGame]);

  const nextMatch = useMemo(() => {
    if (!selectedGame) return null;
    return selectedGame.fixtures
      .filter((f) => f.status !== "FINISHED" && f.scheduledAt > now)
      .sort((a, b) => a.scheduledAt - b.scheduledAt)[0];
  }, [selectedGame, now]);

  const renderHub = () => {
    return (
      <main className="mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
        <section className="mb-10 text-center">
          <Badge variant="info" className="mb-3">
            <Zap className="h-3 w-3" /> Season 2026
          </Badge>
          <h1 className="font-display text-4xl font-black uppercase tracking-tight text-white sm:text-5xl">
            Tournament <span className="text-cyan-400">Hub</span>
          </h1>
          <p className="mx-auto mt-3 max-w-2xl text-slate-400">
            Register your squad, track live standings, and manage every bracket
            across the biggest mobile and PC esports titles.
          </p>
        </section>

        <section className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
          {games.map((game) => {
            const isRegistered = user?.role === "team"
              ? game.registeredTeamIds.includes(user.teamId)
              : false;
            return (
              <GameCard
                key={game.id}
                game={game}
                user={user}
                isRegistered={isRegistered}
                onSelect={() => {
                  setSelectedGameId(game.id);
                  setActiveTab("standings");
                }}
                onRegister={(e) => {
                  e.stopPropagation();
                  registerTeamForGame(game.id);
                }}
              />
            );
          })}
        </section>
      </main>
    );
  };

  const renderDashboard = () => {
    if (!selectedGame) return null;
    const theme = ACCENT[selectedGame.accent];
    const isAdmin = user?.role === "admin";

    return (
      <main className="mx-auto max-w-7xl px-4 py-6 sm:px-6 lg:px-8">
        <button
          onClick={() => setSelectedGameId(null)}
          className="mb-4 inline-flex items-center gap-2 rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-slate-300 transition hover:bg-slate-800"
        >
          <ChevronLeft className="h-4 w-4" /> Back to Hub
        </button>

        <div
          className={cn(
            "relative overflow-hidden rounded-2xl border bg-slate-900/80 p-6 shadow-xl backdrop-blur",
            theme.border
          )}
        >
          <div
            className={cn(
              "absolute inset-x-0 top-0 h-1 bg-gradient-to-r",
              theme.gradient
            )}
          />
          <div className="relative flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
            <div className="flex items-start gap-4">
              <div
                className={cn(
                  "flex h-14 w-14 items-center justify-center rounded-xl border bg-slate-950",
                  theme.border,
                  theme.text
                )}
              >
                {GAME_ICONS[selectedGame.id] || <Gamepad2 className="h-7 w-7" />}
              </div>
              <div>
                <h2
                  className={cn(
                    "font-display text-3xl font-black uppercase tracking-tight text-white"
                  )}
                >
                  {selectedGame.name}
                </h2>
                <div className="mt-1 flex flex-wrap items-center gap-3 text-sm text-slate-400">
                  <span className="flex items-center gap-1">
                    <Calendar className="h-4 w-4" />{" "}
                    {formatDateTime(selectedGame.startAt)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Trophy className="h-4 w-4 text-amber-400" /> 1st{" "}
                    {formatCurrency(selectedGame.prizeFirst)}
                  </span>
                  <span className="flex items-center gap-1">
                    <Medal className="h-4 w-4 text-slate-400" /> 2nd{" "}
                    {formatCurrency(selectedGame.prizeSecond)}
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-col items-start gap-2 sm:flex-row sm:items-center">
              <div
                className={cn(
                  "rounded-xl border px-4 py-3 text-center",
                  theme.border,
                  theme.soft
                )}
              >
                <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">
                  Next Match
                </p>
                <p className="font-display text-lg font-bold text-white">
                  {nextMatch ? (
                    <span className={theme.text}>
                      {formatCountdown(nextMatch.scheduledAt - now)}
                    </span>
                  ) : (
                    <span className="text-slate-500">—</span>
                  )}
                </p>
              </div>
              {user?.role === "team" &&
                !selectedGame.registeredTeamIds.includes(user.teamId) &&
                selectedGame.registeredTeamIds.length < selectedGame.maxTeams && (
                  <button
                    onClick={() => registerTeamForGame(selectedGame.id)}
                    className={cn(
                      "rounded-lg bg-gradient-to-r px-4 py-3 text-sm font-bold uppercase tracking-wider text-white shadow-lg transition hover:brightness-110",
                      theme.gradient
                    )}
                  >
                    Register Team
                  </button>
                )}
            </div>
          </div>
        </div>

        <div className="mt-6 flex flex-wrap gap-2">
          {(["standings", "roster", "fixtures"] as const).map((tab) => (
            <button
              key={tab}
              onClick={() => setActiveTab(tab)}
              className={cn(
                "rounded-lg border px-4 py-2 text-xs font-bold uppercase tracking-wider transition",
                activeTab === tab
                  ? cn(
                      "border-transparent bg-gradient-to-r text-white shadow-lg",
                      theme.gradient
                    )
                  : "border-slate-700 bg-slate-900/60 text-slate-400 hover:bg-slate-800"
              )}
            >
              {tab}
            </button>
          ))}
        </div>

        {activeTab === "roster" && (
          <section className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
            {selectedGame.registeredTeamIds.map((id) => {
              const team = teams.find((t) => t.id === id);
              if (!team) return null;
              return (
                <div
                  key={team.id}
                  className={cn(
                    "rounded-xl border bg-slate-900/70 p-4 transition hover:-translate-y-0.5 hover:bg-slate-800/80",
                    theme.border
                  )}
                >
                  <div className="mb-3 flex items-start justify-between">
                    <h4 className="font-display text-lg font-bold text-white">
                      {team.name}
                    </h4>
                    {user?.role === "team" && user.teamId === team.id && (
                      <Badge variant="info">You</Badge>
                    )}
                  </div>
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Manager
                  </p>
                  <p className="text-sm text-slate-300">{team.manager}</p>
                  <p className="mt-3 text-xs font-semibold uppercase tracking-wider text-slate-500">
                    Roster
                  </p>
                  <p className="text-sm text-slate-300">
                    {team.members.join(", ")}
                  </p>
                  {isAdmin && (
                    <button
                      onClick={() => banTeam(selectedGame.id, team.id)}
                      className="mt-4 flex w-full items-center justify-center gap-2 rounded-lg border border-rose-500/30 bg-rose-500/10 px-3 py-2 text-xs font-bold uppercase tracking-wider text-rose-400 transition hover:bg-rose-500/20"
                    >
                      <ShieldAlert className="h-4 w-4" /> Ban / Disqualify
                    </button>
                  )}
                </div>
              );
            })}
          </section>
        )}

        {activeTab === "standings" && (
          <section className="mt-6 overflow-hidden rounded-2xl border border-slate-800 bg-slate-900/70 shadow-xl">
            <div className="flex items-center justify-between border-b border-slate-800 px-5 py-4">
              <h3 className="font-display text-lg font-bold uppercase tracking-wide text-white">
                Leaderboard / Standings
              </h3>
              {isAdmin && (
                <button
                  onClick={() => {
                    setSavedFlash(true);
                    setTimeout(() => setSavedFlash(false), 1200);
                  }}
                  className={cn(
                    "flex items-center gap-2 rounded-lg px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-white transition",
                    savedFlash
                      ? "bg-emerald-500"
                      : cn("bg-gradient-to-r", theme.gradient)
                  )}
                >
                  <Save className="h-4 w-4" />
                  {savedFlash ? "Saved" : "Save Standings"}
                </button>
              )}
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm">
                <thead className="bg-slate-950/60 text-xs font-bold uppercase tracking-wider text-slate-400">
                  <tr>
                    <th className="px-5 py-3">Rank</th>
                    <th className="px-5 py-3">Team</th>
                    <th className="px-5 py-3 text-center">Matches</th>
                    <th className="px-5 py-3 text-center">Wins</th>
                    <th className="px-5 py-3 text-center">Kills / Points</th>
                    <th className="px-5 py-3 text-center">Total Score</th>
                    {isAdmin && <th className="px-5 py-3">Actions</th>}
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-800">
                  {sortedStandings.map((s, index) => {
                    const team = teams.find((t) => t.id === s.teamId);
                    if (!team) return null;
                    return (
                      <tr
                        key={s.teamId}
                        className={cn(
                          "transition hover:bg-slate-800/50",
                          index === 0 && "bg-amber-500/5"
                        )}
                      >
                        <td className="px-5 py-3">
                          <div className="flex items-center gap-2">
                            {index === 0 && (
                              <Crown className="h-4 w-4 text-amber-400" />
                            )}
                            <span
                              className={cn(
                                "font-display font-bold",
                                index === 0
                                  ? "text-amber-400"
                                  : index === 1
                                  ? "text-slate-300"
                                  : index === 2
                                  ? "text-amber-600"
                                  : "text-slate-500"
                              )}
                            >
                              #{index + 1}
                            </span>
                          </div>
                        </td>
                        <td className="px-5 py-3 font-semibold text-white">
                          {team.name}
                        </td>
                        {isAdmin ? (
                          <>
                            <td className="px-5 py-3 text-center">
                              <input
                                type="number"
                                min={0}
                                value={s.matches}
                                onChange={(e) =>
                                  updateStanding(
                                    selectedGame.id,
                                    s.teamId,
                                    "matches",
                                    Number(e.target.value)
                                  )
                                }
                                className="w-16 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-center text-white outline-none focus:border-cyan-500"
                              />
                            </td>
                            <td className="px-5 py-3 text-center">
                              <input
                                type="number"
                                min={0}
                                value={s.wins}
                                onChange={(e) =>
                                  updateStanding(
                                    selectedGame.id,
                                    s.teamId,
                                    "wins",
                                    Number(e.target.value)
                                  )
                                }
                                className="w-16 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-center text-white outline-none focus:border-cyan-500"
                              />
                            </td>
                            <td className="px-5 py-3 text-center">
                              <input
                                type="number"
                                min={0}
                                value={s.killsPoints}
                                onChange={(e) =>
                                  updateStanding(
                                    selectedGame.id,
                                    s.teamId,
                                    "killsPoints",
                                    Number(e.target.value)
                                  )
                                }
                                className="w-20 rounded border border-slate-700 bg-slate-950 px-2 py-1 text-center text-white outline-none focus:border-cyan-500"
                              />
                            </td>
                            <td className="px-5 py-3 text-center">
                              <input
                                type="number"
                                min={0}
                                value={s.totalScore}
                                onChange={(e) =>
                                  updateStanding(
                                    selectedGame.id,
                                    s.teamId,
                                    "totalScore",
                                    Number(e.target.value)
                                  )
                                }
                                className={cn(
                                  "w-20 rounded border px-2 py-1 text-center font-display font-bold outline-none focus:border-cyan-500",
                                  theme.border,
                                  theme.text,
                                  "bg-slate-950"
                                )}
                              />
                            </td>
                            <td className="px-5 py-3">
                              <button
                                onClick={() =>
                                  banTeam(selectedGame.id, s.teamId)
                                }
                                className="rounded-lg border border-rose-500/30 bg-rose-500/10 px-2.5 py-1 text-xs font-bold uppercase tracking-wider text-rose-400 transition hover:bg-rose-500/20"
                              >
                                Ban
                              </button>
                            </td>
                          </>
                        ) : (
                          <>
                            <td className="px-5 py-3 text-center text-slate-300">
                              {s.matches}
                            </td>
                            <td className="px-5 py-3 text-center text-slate-300">
                              {s.wins}
                            </td>
                            <td className="px-5 py-3 text-center text-slate-300">
                              {s.killsPoints}
                            </td>
                            <td
                              className={cn(
                                "px-5 py-3 text-center font-display font-bold",
                                theme.text
                              )}
                            >
                              {s.totalScore}
                            </td>
                          </>
                        )}
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
            {sortedStandings.length === 0 && (
              <div className="p-8 text-center text-sm text-slate-500">
                No teams registered yet.
              </div>
            )}
          </section>
        )}

        {activeTab === "fixtures" && (
          <section className="mt-6">
            {isAdmin && (
              <div className="mb-4 flex justify-end">
                <button
                  onClick={() => addFixture(selectedGame.id)}
                  className={cn(
                    "flex items-center gap-2 rounded-lg bg-gradient-to-r px-4 py-2 text-xs font-bold uppercase tracking-wider text-white shadow-lg transition hover:brightness-110",
                    theme.gradient
                  )}
                >
                  <Plus className="h-4 w-4" /> Add Fixture
                </button>
              </div>
            )}
            <div className="grid gap-4 lg:grid-cols-2">
              {selectedGame.fixtures.map((f) => {
                const a = teams.find((t) => t.id === f.teamAId);
                const b = teams.find((t) => t.id === f.teamBId);
                return (
                  <div
                    key={f.id}
                    onClick={() => setFixtureModal(f)}
                    className={cn(
                      "group cursor-pointer rounded-2xl border bg-slate-900/70 p-5 transition hover:-translate-y-0.5 hover:bg-slate-800/80",
                      theme.border
                    )}
                  >
                    <div className="mb-3 flex items-center justify-between">
                      <Badge
                        variant={
                          f.status === "LIVE"
                            ? "danger"
                            : f.status === "FINISHED"
                            ? "neutral"
                            : "info"
                        }
                      >
                        <StatusDot status={f.status} />
                        {f.status}
                      </Badge>
                      <span className="flex items-center gap-1 text-xs text-slate-500">
                        <Clock className="h-3.5 w-3.5" />
                        {formatDateTime(f.scheduledAt)}
                      </span>
                    </div>

                    <div className="flex items-center justify-between gap-4">
                      <div className="flex-1 text-center">
                        <p className="font-display text-lg font-bold text-white">
                          {a?.name || "TBD"}
                        </p>
                        <p className="text-xs text-slate-500">
                          {a?.members.slice(0, 3).join(", ") || "—"}
                        </p>
                      </div>
                      <div className="flex flex-col items-center">
                        <Swords className={cn("h-5 w-5", theme.text)} />
                        <span className="text-[10px] font-bold uppercase tracking-widest text-slate-600">
                          VS
                        </span>
                      </div>
                      <div className="flex-1 text-center">
                        <p className="font-display text-lg font-bold text-white">
                          {b?.name || "TBD"}
                        </p>
                        <p className="text-xs text-slate-500">
                          {b?.members.slice(0, 3).join(", ") || "—"}
                        </p>
                      </div>
                    </div>

                    {isAdmin && (
                      <div
                        onClick={(e) => e.stopPropagation()}
                        className="mt-4 grid gap-3 border-t border-slate-800 pt-4 sm:grid-cols-4"
                      >
                        <select
                          value={f.teamAId}
                          onChange={(e) =>
                            updateFixture(selectedGame.id, f.id, {
                              teamAId: e.target.value,
                            })
                          }
                          className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-white outline-none focus:border-cyan-500"
                        >
                          {selectedGame.registeredTeamIds.map((id) => {
                            const t = teams.find((x) => x.id === id);
                            return (
                              <option key={id} value={id}>
                                {t?.name}
                              </option>
                            );
                          })}
                        </select>
                        <select
                          value={f.teamBId}
                          onChange={(e) =>
                            updateFixture(selectedGame.id, f.id, {
                              teamBId: e.target.value,
                            })
                          }
                          className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-white outline-none focus:border-cyan-500"
                        >
                          {selectedGame.registeredTeamIds.map((id) => {
                            const t = teams.find((x) => x.id === id);
                            return (
                              <option key={id} value={id}>
                                {t?.name}
                              </option>
                            );
                          })}
                        </select>
                        <select
                          value={f.status}
                          onChange={(e) =>
                            updateFixture(selectedGame.id, f.id, {
                              status: e.target.value as FixtureStatus,
                            })
                          }
                          className="rounded-lg border border-slate-700 bg-slate-950 px-2 py-1.5 text-xs text-white outline-none focus:border-cyan-500"
                        >
                          <option value="UPCOMING">UPCOMING</option>
                          <option value="LIVE">LIVE</option>
                          <option value="FINISHED">FINISHED</option>
                        </select>
                        <button
                          onClick={() =>
                            deleteFixture(selectedGame.id, f.id)
                          }
                          className="flex items-center justify-center gap-1 rounded-lg border border-rose-500/30 bg-rose-500/10 px-2 py-1.5 text-xs font-bold uppercase tracking-wider text-rose-400 transition hover:bg-rose-500/20"
                        >
                          <Trash2 className="h-3.5 w-3.5" /> Remove
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
            {selectedGame.fixtures.length === 0 && (
              <div className="rounded-2xl border border-slate-800 bg-slate-900/50 p-8 text-center text-sm text-slate-500">
                No fixtures scheduled yet.
              </div>
            )}
          </section>
        )}
      </main>
    );
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden bg-slate-950 text-slate-100">
      <div className="pointer-events-none absolute inset-x-0 top-0 h-[500px] bg-gradient-to-b from-slate-900 to-transparent opacity-80" />
      <header className="sticky top-0 z-30 border-b border-slate-800 bg-slate-950/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-3 sm:px-6 lg:px-8">
          <div
            className="flex cursor-pointer items-center gap-2"
            onClick={() => setSelectedGameId(null)}
          >
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-lg shadow-cyan-500/20">
              <Gamepad2 className="h-5 w-5" />
            </div>
            <span className="font-display text-lg font-black uppercase tracking-wide text-white">
              Arena<span className="text-cyan-400">.</span>
            </span>
          </div>

          <div className="flex items-center gap-3">
            {user && (
              <>
                <Badge
                  variant={user.role === "admin" ? "warning" : "info"}
                  className="hidden sm:inline-flex"
                >
                  {user.role === "admin" ? (
                    <>
                      <UserCog className="h-3 w-3" /> {user.name}
                    </>
                  ) : (
                    <>
                      <Users className="h-3 w-3" />{" "}
                      {teams.find((t) => t.id === user.teamId)?.name}
                    </>
                  )}
                </Badge>
                <button
                  onClick={() => setUser(null)}
                  className="inline-flex items-center gap-1.5 rounded-lg border border-slate-700 bg-slate-900/60 px-3 py-1.5 text-xs font-bold uppercase tracking-wider text-slate-300 transition hover:bg-slate-800"
                >
                  <LogOut className="h-3.5 w-3.5" /> Logout
                </button>
              </>
            )}
          </div>
        </div>
      </header>

      {!user ? (
        <AuthModal
          role={role}
          teams={teams}
          onLogin={handleAuth}
          onSwitchRole={switchRole}
        />
      ) : selectedGameId ? (
        renderDashboard()
      ) : (
        renderHub()
      )}

      {user && (
        <button
          onClick={switchRole}
          className="fixed bottom-6 right-6 z-40 flex items-center gap-2 rounded-full border border-slate-700 bg-slate-900/90 px-4 py-2 text-xs font-bold uppercase tracking-wider text-slate-300 shadow-2xl backdrop-blur transition hover:border-cyan-500/50 hover:text-cyan-400"
        >
          <Zap className="h-3.5 w-3.5 text-cyan-400" />
          Switch Role: {role === "team" ? "Admin" : "Team"}
        </button>
      )}

      {fixtureModal && selectedGame && (
        <LiveStreamModal
          game={selectedGame}
          fixture={fixtureModal}
          teams={teams}
          onClose={() => setFixtureModal(null)}
        />
      )}
    </div>
  );
}
